package com.example.weatherprojectapi;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Date;

public class City {
    private String cityName;
    private String weatherDescription;
    private int realFeelTemperature;
    private int currentTemperature;
    private int minimumTemperature;
    private int maximumTemperature;
    private int humidity;
    private float windSpeed;

    public City(String cityName)
    {
        this.cityName = cityName;
    }

    //update the information data about the city
    public void updateCityDetails()
    {
        try {

            MyData myData = new MyData(Definition.API_TOKEN);//create data obj to get info
            JSONObject mainJsonObject = myData.getData(this.cityName);//getting json object
            Log.i("CITY","JSON is initialized");
            if(mainJsonObject == null)//if mainJsonNull so return
            {
                return;//end method
            }
            //weather:
            this.weatherDescription = mainJsonObject.getJSONArray("weather").getJSONObject(0).getString("description");

            //main
            JSONObject tempJsonObj;
            tempJsonObj = mainJsonObject.getJSONObject("main");//temp json obj
            this.currentTemperature = (int)(Float.parseFloat(tempJsonObj.getString("temp")));
            this.realFeelTemperature = (int)(Float.parseFloat(tempJsonObj.getString("feels_like")));
            this.maximumTemperature = (int)(Float.parseFloat(tempJsonObj.getString("temp_max")));
            this.minimumTemperature = (int)(Float.parseFloat(tempJsonObj.getString("temp_min")));
            this.humidity = (int)(Float.parseFloat(tempJsonObj.getString("humidity")));

            //wind
            tempJsonObj = mainJsonObject.getJSONObject("wind");//temp json obj
            this.windSpeed = Float.parseFloat(tempJsonObj.getString("speed"));
            Log.i("CITY","All attributes has been updated");
        }
        catch (JSONException jsonException)
        {
            Log.i("CITY",jsonException.getMessage());
            jsonException.printStackTrace();
        }

    }

    public String getCityName() {
        return cityName;
    }

    public String getWeatherDescription() {
        return weatherDescription;
    }

    public int getRealFeelTemperature() {
        return realFeelTemperature;
    }

    public int getCurrentTemperature() {
        return currentTemperature;
    }

    public int getMinimumTemperature() {
        return minimumTemperature;
    }

    public int getMaximumTemperature() {
        return maximumTemperature;
    }

    public int getHumidity() {
        return humidity;
    }

    public float getWindSpeed() {
        return windSpeed;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public void setWeatherDescription(String weatherDescription) {
        this.weatherDescription = weatherDescription;
    }

    public void setRealFeelTemperature(int realFeelTemperature) {
        this.realFeelTemperature = realFeelTemperature;
    }

    public void setCurrentTemperature(int currentTemperature) {
        this.currentTemperature = currentTemperature;
    }

    public void setMinimumTemperature(int minimumTemperature) {
        this.minimumTemperature = minimumTemperature;
    }

    public void setMaximumTemperature(int maximumTemperature) {
        this.maximumTemperature = maximumTemperature;
    }

    public void setHumidity(int humidity) {
        this.humidity = humidity;
    }

    public void setWindSpeed(float windSpeed) {
        this.windSpeed = windSpeed;
    }
}
