package com.example.weatherprojectapi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class CityListAdapter extends ArrayAdapter {

    private List<City> cityList;
    private Context activity;
    private int layoutId;
    private MyCities cities;

    public CityListAdapter(Context context,int resource,@NonNull List objects,MyCities cities)
    {
        super(context,resource,objects);
        this.activity = context;
        this.layoutId = resource;
        this.cityList = objects;
        this.cities = cities;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        City city = this.cityList.get(position);

        LayoutInflater inflater = LayoutInflater.from(this.activity);
        convertView = inflater.inflate(this.layoutId,parent,false);

        //get the Views
        TextView citysName = convertView.findViewById(R.id.cityName);
        ImageView starImage = convertView.findViewById(R.id.star);

        //set the Views
        citysName.setText(city.getCityName());
        if(this.cities.getCities().get(position) == this.cities.getPrimaryCity())//if city is primary city show the primary star next to it
            starImage.setVisibility(View.VISIBLE);
        else
            starImage.setVisibility(View.INVISIBLE);

        return convertView;
    }
}
