package com.example.weatherprojectapi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private AppManager appManager;//Class manage app's logic
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.appManager = new AppManager(findViewById(android.R.id.content).getRootView(),this,this);//creating manager


    }


    public void onMenuButtonClick(View view)
    {
        this.appManager.onClick(view);
    }

    public void  onAddButtonClick(View view) { this.appManager.onClickNewCityToAdd(view);}







}
