package com.example.weatherprojectapi;


import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//this class responsible for saving and loading data like chosen cities
public class MemoryManager {

    public static final int PRIMARY_SIGN = 1;
    public static final int NOT_PRIMARY_SIGN = 0;

    private AppManager appManager;
    private Context context;
    private MyCities myCities;
    private File filePath;
    private Activity activity;


    public MemoryManager(AppManager appManager)
    {
        this.appManager = appManager;
        this.activity = this.appManager.getActivity();
        this.context = this.appManager.getMainContext();
        this.myCities = this.appManager.getMyCities();
        this.filePath = this.context.getFilesDir();//get file dir

        this.init();
    }

    //init the file manager
    private void init()
    {
        try
        {
            File file = new File(this.filePath,Definition.SAVING_FILE_NAME);
            if (file.createNewFile())//creating new file / first time logged in app
            {
                /*ask for first city
                City city = new City(this.appManager.getFirstNewCityInput().getText().toString());//get the first city
                this.myCities.setPrimaryCity(city);//first city will be primary

                this.saveStringData();//save
                this.appManager.getListAdapter().notifyDataSetChanged();//change data in adapter*/
                Toast.makeText(this.context,"SAVE FILE CREATED",Toast.LENGTH_SHORT).show();
            }
            else
            {
                //Toast.makeText(this.context,"FILE ALREADY EXIST",Toast.LENGTH_SHORT).show();
            }

        }
        catch (IOException e)
        {
            Toast.makeText(this.context,"ERROR CREATE SAVE FILE",Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    //saving the data to the file
    public void saveStringData()
    {
        //check if there is not permission to write
        if(this.context.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
        {
            this.activity.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
        }


            String temp = "";
            try {
                File file = new File(this.filePath, Definition.SAVING_FILE_NAME);
                FileWriter fileWriter = new FileWriter(file);
                for (City city : this.myCities.getCities()) {
                    temp += city.getCityName();
                    fileWriter.write(city.getCityName());
                    if (city == this.myCities.getPrimaryCity())//if city is primary
                    {
                        fileWriter.write(" " + PRIMARY_SIGN + " ");//add 1 as represent the primary city
                        temp += String.valueOf(" " + PRIMARY_SIGN + " ");
                    } else {
                        fileWriter.write(" " + NOT_PRIMARY_SIGN + " ");//0 is not primary city
                        temp += String.valueOf(" " + NOT_PRIMARY_SIGN + " ");
                    }
                    fileWriter.flush();
                }
                Log.i("WRITE_TEST", temp);
                fileWriter.close();


                Scanner scanner = new Scanner(file);
                while (scanner.hasNextLine())//scan the file
                {
                    Log.i("WRITE_TEST", scanner.nextLine());
                }
                if (file.length() == 0)
                    Log.i("WRITE_TEST", "EMPTY FILE");
                scanner.close();
                fileWriter.close();

            } catch (IOException e) {
                Log.i("WRITE_TEST",e.getMessage());
                e.printStackTrace();
            }

    }

    //loading saved string data and update the list of cities and primary city
    public void loadStringData()
    {
        try
        {
            File file = new File(this.filePath,Definition.SAVING_FILE_NAME);
            if(file.length() == 0)//check if file empty
                return;//exit the method
            Scanner scanner = new Scanner(file);
            //scanner.useDelimiter(String.valueOf(PRIMARY_SIGN));//cut when '1'
            //scanner.useDelimiter(String.valueOf(NOT_PRIMARY_SIGN));//cut when '0'
            List<City> cities = new ArrayList<City>();
            City primaryCity = null;
            //Log.i("TEST","READING: " + scanner.next());

            while (scanner.hasNext())//scan the file
            {
                String nextCityString = scanner.next();//get next string -> city name
                City loadedCity = new City(nextCityString);//create city object
                cities.add(loadedCity);//add city object
                String isPrimary = scanner.next();//0 -> no, 1 -> primary city
                if(Integer.parseInt(isPrimary) == PRIMARY_SIGN)//check if primary city
                    primaryCity = loadedCity;//update the primary city
            }
            scanner.close();
            if(primaryCity != null)//if everything is ok so set the primary city that we loaded
                this.myCities.setPrimaryCity(primaryCity);
            else
                this.myCities.setPrimaryCity(cities.get(0));//set the first city in List to be the primary

            this.myCities.setCities(cities);//set loaded cities

        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    //reset Data / clear text file
    public void resetData()
    {
        try
        {
            File file = new File(this.filePath, Definition.SAVING_FILE_NAME);
            PrintWriter printWriter = new PrintWriter(file);
            printWriter.print("");
            printWriter.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    //return true if the save file is empty
    public boolean isSaveFileEmpty()
    {
        File file = new File(this.filePath,Definition.SAVING_FILE_NAME);
        return (file.length() == 0);
    }

}
