package com.example.weatherprojectapi;

public class Definition {
    public static String API_TOKEN = "f41f04b249932526de81aeac1d0f13ab";//can be changed because token cant over
    public static final int ERROR_CODE = -999;
    public static final char CELCIUS = '°';
    //index of current scene
    public static final int PRIMARY_CITY_SCENE = 0;
    public static final int SEARCH_SCENE = 1;
    public static final int MY_CITIES_SCENE = 2;
    public static final int SETTINGS_SCENE = 3;
    public static final String SAVING_FILE_NAME = "cities_name";
    public static final int SECOND = 1000; //1sec = 1000ms
}
