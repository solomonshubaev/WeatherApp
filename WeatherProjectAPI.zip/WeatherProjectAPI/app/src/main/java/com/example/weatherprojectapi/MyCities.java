package com.example.weatherprojectapi;

import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MyCities {

    private List<City> cities;
    private City primaryCity;

    public MyCities()
    {
        this.cities = new ArrayList<City>();
    }

    //adding city to favorites to the end.
    public void addCityToFavorites(City newCity)
    {
        this.cities.add(newCity);
    }

    //return the first obj in list that is the primary city
    public City getPrimaryCity()
    {
        return this.primaryCity;
    }

    //remove city from list
    public boolean removeCityFromList(String cityToRemove)
    {
        if(this.cities.size() == 1)//last item in the List cant be deleted
        {
            return false;//we cant delete last item
        }
        for(int i = 0; i <this.cities.size(); i++)//scan the array
        {
            if(this.cities.get(i).getCityName().equals(cityToRemove))//check if the city is the same to be removed
            {
                this.cities.remove(i);//remove the city
                if(getPrimaryCity().getCityName().equals(cityToRemove))//check if city was primary
                {
                    this.primaryCity = this.cities.get(0);//set the first city to be primary
                }
                return true;//(we found what we have look for)
            }
        }
        return false;//should not get here, if it does than something go wrong :)
    }

    public List<City> getCities() {
        return cities;
    }

    public void setPrimaryCity(City newPrimaryCity)
    {
        this.primaryCity = newPrimaryCity;
    }

    public void setCities(List<City> cities) {
        this.cities = cities;
    }
}
