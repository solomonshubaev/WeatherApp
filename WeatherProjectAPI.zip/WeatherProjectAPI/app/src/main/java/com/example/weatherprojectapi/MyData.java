package com.example.weatherprojectapi;

import android.os.NetworkOnMainThreadException;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import org.json.JSONException;
import org.json.JSONObject;


public class MyData {
    private String token;
    private HttpURLConnection connection;
    public MyData(String token)
    {
        this.token = token;
    }
    //responsible to get api data
    public JSONObject getData(String cityName)
    {
        try {
            URL url = new URL("https://api.openweathermap.org/data/2.5/weather?q="+cityName+"&APPID="+this.token+"&units=metric"); //url
            //URL url = new URL("https://api.openweathermap.org/data/2.5/weather?q=Ashqelon&APPID=f41f04b249932526de81aeac1d0f13ab");
            Log.i("API_GET","URL " + url);

            this.connection = (HttpURLConnection) url.openConnection();
            InputStream inputStream = this.connection.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            StringBuilder stringBuilder = new StringBuilder();
            int currentChar = 0;
            do {
                currentChar = inputStreamReader.read();
                stringBuilder.append((char) currentChar);
            } while (currentChar != -1);

            Log.i("API_GET",stringBuilder.toString());

            return (new JSONObject(stringBuilder.toString()));
        }
        catch (NetworkOnMainThreadException exception)
        {
            exception.printStackTrace();
        }
        catch (JSONException jsonException)
        {
            jsonException.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally {
            this.connection.disconnect();//close connection
        }
        return null;//return null if unsuccessful

    }

    private void printTest(String jString)
    {
        try {
            JSONObject mainJsonObject = new JSONObject(jString);
            Log.i("json_v","temp: " + mainJsonObject.getJSONObject("main").getString("temp"));
        }
        catch (JSONException jException)//catch an exception
        {
            jException.printStackTrace();
        }

    }
}
