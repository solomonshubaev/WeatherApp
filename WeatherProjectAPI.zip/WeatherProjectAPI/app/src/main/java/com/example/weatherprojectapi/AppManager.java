package com.example.weatherprojectapi;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.*;

import java.util.Date;

//This class will be responsible to all the app's logic
public class AppManager {

    private Activity activity;
    private Context mainContext;
    private CityListAdapter listAdapter;
    private Thread apiThread;
    private MyCities myCities;
    private MemoryManager memoryManager;//save load manager

    private TextView cityName;
    private TextView weatherDescription;
    private TextView realFeelTemperature;
    private TextView currentTemperature;
    private TextView miniMaxTemperature;
    private TextView humidity;
    private TextView windSpeed;
    private TextView lastUpdate;

    private TableLayout primaryCityView;
    private ListView citiesListView;
    private LinearLayout addMenuLayout;
    private Button addCityButton;//responsible to add new city to favorites
    private EditText newCityInput;//input of city's string(name)

    private LinearLayout firstAddCityMenu;//starting window, first time opening app
    private EditText firstNewCityInput;//city name input first window
    private TableLayout buttonMenu;//buttons menu


    private View activeView;

    public AppManager(View view,Context context,Activity activity)
    {
        this.activity = activity;
        this.mainContext = context;
        this.cityName =view.findViewById(R.id.cityName);
        this.currentTemperature = view.findViewById(R.id.currentTemperature);
        this.humidity = view.findViewById(R.id.humidity);
        this.miniMaxTemperature = view.findViewById(R.id.minMaxTemp);
        this.windSpeed = view.findViewById(R.id.wind);
        this.realFeelTemperature = view.findViewById(R.id.feelsLike);
        this.weatherDescription = view.findViewById(R.id.description);
        this.lastUpdate = view.findViewById(R.id.lastUpdated);
        this.primaryCityView = view.findViewById(R.id.citysParameters);
        this.activeView = this.primaryCityView;//primary city view is the active
        this.citiesListView = view.findViewById(R.id.citiesList);
        this.addMenuLayout = view.findViewById(R.id.addMenu);
        this.newCityInput = view.findViewById(R.id.citysNameInput);
        this.firstAddCityMenu = view.findViewById(R.id.firstWindow);
        this.firstNewCityInput = view.findViewById(R.id.firstCityInput);
        this.buttonMenu =view.findViewById(R.id.Buttons);
        init();

    }

    public void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.main://case main button pressed
                if(!isSpecificSceneActive(this.primaryCityView))//if the pressed menu is OFF
                {
                    this.changeView(this.primaryCityView);//change view
                    this.addMenuLayout.setVisibility(View.GONE);
                }
                try {
                    updateMainCity();//update to relevant details
                    this.apiThread.join();//wait until data will be received
                    setAllCityParameters(this.myCities.getPrimaryCity());//update UI
                }
                catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
                break;
            case R.id.myCities://favorites cities pressed
                if(!isSpecificSceneActive(this.citiesListView) && !isSpecificSceneActive(this.addMenuLayout))//if the pressed menu is OFF
                {
                    this.changeView(this.citiesListView);//change view
                    this.addMenuLayout.setVisibility(View.VISIBLE);
                }
                break;

        }
    }

    public void onClickNewCityToAdd(View view)
    {
        City newCity;
        if(isSpecificSceneActive(this.firstAddCityMenu))//if first window is visible so go to parameters menu
        {
            this.primaryCityView.setVisibility(View.VISIBLE);//set the primary window ON
            this.buttonMenu.setVisibility(View.VISIBLE);//set the button menu ON
            this.firstAddCityMenu.setVisibility(View.GONE);//OFF the first window
             newCity = new City(this.firstNewCityInput.getText().toString());//create city object with names input
        }
        else//if not in first window
        {
             newCity = new City(this.newCityInput.getText().toString());//create city object with names input
        }
        this.myCities.addCityToFavorites(newCity);//add to favorites
        this.myCities.setPrimaryCity(newCity);
        this.memoryManager.saveStringData();//save the new data
        this.listAdapter.notifyDataSetChanged();//update the adapter
        Toast.makeText(this.mainContext,"CITY ADDED SUCCESSFULLY",Toast.LENGTH_LONG).show();//show message to user via toast
    }

    //change the view displaying on screen and turns off the previous view
    private void changeView(View viewToDisplay)
    {
        this.activeView.setVisibility(View.GONE);//turn off previous view
        viewToDisplay.setVisibility(View.VISIBLE);//turn on new view
        this.activeView = viewToDisplay;//update
    }

    //update city's details
    private void updateMainCity()
    {
        //thread to get api request, not interrupting to UI thread
        this.apiThread = new Thread(() -> {
            this.myCities.getPrimaryCity().updateCityDetails();//update cities details
            Log.i("INIT_THREAD","Thread has been finished");
        });
        apiThread.start();
    }

    //init first vars
    private void init()
    {
        this.myCities = new MyCities();//init
        this.memoryManager = new MemoryManager(this);
        //this.memoryManager.resetData();//use only if u want to reset the data. (Developer option)
        showStartingWindow();//show the correct window

        this.memoryManager.loadStringData();//Load the saved data of used cities
        initAdapter();//setting the adapter
    }

    //show the starting window that needed to show
    public void showStartingWindow()
    {
        if (!this.memoryManager.isSaveFileEmpty())//if save file not empty
        {
            this.buttonMenu.setVisibility(View.VISIBLE);
            this.primaryCityView.setVisibility(View.VISIBLE);
        }
        else
        {
            this.firstAddCityMenu.setVisibility(View.VISIBLE);
        }
    }

    //set city to be primary city
    public void setPrimaryCity(City newPrimaryCity)
    {
        try {
            this.myCities.setPrimaryCity(newPrimaryCity);
            updateMainCity();
            this.apiThread.join();//wait to thread
            City primaryCity = this.myCities.getPrimaryCity();//get primary city
            setAllCityParameters(primaryCity);
        }
        catch (InterruptedException e ) {
            e.printStackTrace();
        }
    }

    //setting the adapter
    public void initAdapter()
    {
        this.listAdapter = new CityListAdapter(this.mainContext,R.layout.city_view,this.myCities.getCities(),this.myCities);
        this.citiesListView.setAdapter(this.listAdapter);
        this.citiesListView.setOnItemClickListener(((parent, view, position, id) ->
        {
            Log.i("Adapter","click");
            City selectedCity = this.myCities.getCities().get(position);//get the selected city from the viewList
            if(this.myCities.getPrimaryCity() != selectedCity)//check that the primary city need to be changed
                setPrimaryCity(selectedCity);//set new primary city
            this.listAdapter.notifyDataSetChanged();
            this.memoryManager.saveStringData();//saving the change
        }));

        this.citiesListView.setOnItemLongClickListener((AdapterView<?> arg0, View arg1,
        int pos, long id) ->
        {
            removeCity(this.myCities.getCities().get(pos).getCityName());//remove the selected city
            this.listAdapter.notifyDataSetChanged();//update adapter
            this.memoryManager.saveStringData();//save the changes
            return true;
        });
    }


    //add city + do all the staff that need
    public void addCity(City newCity)
    {
        this.myCities.addCityToFavorites(newCity);
        //this.listAdapter.notifyDataSetChanged();
    }

    //update the city's to the values from the API
    private void setAllCityParameters(City city)
    {
        this.cityName.setText(city.getCityName());
        this.currentTemperature.setText(String.valueOf(city.getCurrentTemperature())+
                Definition.CELCIUS);
        this.humidity.setText("Humidity is: " + city.getHumidity() + "%");
        this.miniMaxTemperature.setText(String.valueOf(city.getMinimumTemperature())
                + Definition.CELCIUS + "/" +
                String.valueOf(city.getMaximumTemperature()) + Definition.CELCIUS);
        this.realFeelTemperature.setText("Feels like: " + city.getRealFeelTemperature()
                + Definition.CELCIUS);
        this.weatherDescription.setText(city.getWeatherDescription());
        this.windSpeed.setText("Wind speed is: " +
                city.getWindSpeed() + " km/h");
        this.lastUpdate.setText(new Date().toString());

    }
    //check if specific scene is displaying on screen
    public boolean isSpecificSceneActive(View view)
    {
        Log.i("BUTTON","Is visible? : "+String.valueOf(view.getVisibility() == View.VISIBLE));

        return (view.getVisibility() == View.VISIBLE);//if visible return true, else return false.
    }

    //remove the city from favorites
    public void removeCity(String cityName)
    {
        if(this.myCities.removeCityFromList(cityName))//if true (successful removed)
        {
            Toast.makeText(this.mainContext,"CITY HAS BEEN REMOVED",Toast.LENGTH_LONG).show();//show remove message
        }
        else//problem deleting the city
        {
            Toast.makeText(this.mainContext,"COULD NOT REMOVE THE CITY",Toast.LENGTH_LONG).show();//error message
        }
    }

    public TextView getCityName() {
        return cityName;
    }

    public TextView getWeatherDescription() {
        return weatherDescription;
    }

    public TextView getRealFeelTemperature() {
        return realFeelTemperature;
    }

    public TextView getCurrentTemperature() {
        return currentTemperature;
    }

    public LinearLayout getFirstAddCityMenu() {
        return firstAddCityMenu;
    }

    public EditText getFirstNewCityInput() {
        return firstNewCityInput;
    }

    public TableLayout getButtonMenu() {
        return buttonMenu;
    }

    public TextView getMiniMaxTemperature() {
        return miniMaxTemperature;
    }

    public TextView getHumidity() {
        return humidity;
    }

    public TextView getWindSpeed() {
        return windSpeed;
    }

    public TextView getLastUpdate() {
        return lastUpdate;
    }

    public Activity getActivity() {
        return activity;
    }

    public Context getMainContext() {
        return mainContext;
    }

    public CityListAdapter getListAdapter() {
        return listAdapter;
    }

    public MyCities getMyCities() {
        return myCities;
    }
}
